#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

//create a program that will read from a file of code which will reads every charecter from that file defines it as a keyword or indentifiers etc 
//functon will check if the string is keyword or not, by simply taking a string as input and check with predefines and print them as identifier 
int keywords(char str[])
{
    char keywordslist[32][10]={"auto", "break", "case", "char", "const", "continue", "default", "do", "double", 
"else", "enum", "extern", "float", "for", "goto", "if", "int", "long", 
"register", "return", "short", "signed", "sizeof", "static", "struct", 
"switch", "typedef", "union", "unsigned", "void", "volatile", "while"};
    for(int i=0;i<32;i++)
    {
    if(strcmp(str,keywordslist[i])==0)
    {
       printf("| \033[1;33m%-15s\033[0m | %-15s |\n", "KEYWORD", str); 
        return 1;
    }
    }
    return 0;  
} 
// checking if that number is hex or octal
int checkNumberType(char str[])
{
    int len = strlen(str);

    // Hexadecimal: starts with 0x or 0X
    if (len > 2 && str[0] == '0' && (str[1] == 'x' || str[1] == 'X'))
    {
        for (int i = 2; i < len; i++)
        {
            if (!isxdigit(str[i]))
            {
            printf("| INVALID HEX NUMBER | %s |\n", str);
            return 1;
            }
        }
        printf("| HEX NUMBER      | %s |\n", str);
        return 1;
    }

    // Octal: starts with 0 and contains only 0–7
    if (str[0] == '0' && len > 1)
    {
        for (int i = 1; i < len; i++)
        {
        if (str[i] < '0' || str[i] > '7')
            {
        printf("| INVALID OCTAL NUMBER | %s |\n", str);
         return 1;
            }
        }
        printf("| OCTAL NUMBER    | %s |\n", str);
        return 1;
    }

    return 0; 
}
//checking first number type and printing it as number
int  number(char str[])
{
    if (checkNumberType(str))
        return 1;

    for (int i = 0; str[i] != '\0'; i++)
    if (str[i] < '0' || str[i] > '9')
    {
        printf("| INVALID NUMBER | %s |\n", str);
        return 1; 
    }
  printf("| \033[1;32m%-15s\033[0m | %-15s |\n", "NUMBER", str); 
return 1;
}
//function will check if the string is operator or not
int checkoperator(char str[])
{
 char operator[12][3]={"+", "-", "*", "/", "=", "==", "<", ">", "%", "++", "--", "+="};
 for(int i=0;i<12;i++)
 {
    if(strcmp(str,operator[i])==0)
    {
        printf("| \033[1;34m%-15s\033[0m | %-15s |\n", "OPERATOR", str);
        return 1;
    }
 }
 return 0;
}
//checking for symbol
int symbol(char str[])
{
    char symbol[9][3]={"(",")","{", "}", "[", "]", ";", ",","\""};
    for(int i=0;i<9;i++)
    {
    if(strcmp(str,symbol[i])==0)
    {
       printf("| \033[1;36m%-15s\033[0m | %-15s |\n", "SPECIAL SYMBOL", str); 
        return 1; 
    }
    }
    return 0;
}
//identifier check same logic as evryother function receives a string and checks as a identifier or not
int checkidentifier(char str[])
{
   
    if (!isalpha(str[0]) && str[0] != '_')
    {
    printf("| INVALID IDENTIFIER | %s |\n", str);
    return 1;
    }

    for (int i = 1; str[i] != '\0'; i++)
    {
        if(!isalnum(str[i]) && str[i] != '_')
        {
        printf("| INVALID IDENTIFIER | %s |\n", str);
        return 1;
        }
    }
    printf("| \033[1;30m%-15s\033[0m | %-15s |\n", "IDENTIFIER", str);
    return 1;

}
int main(int argc,char *argv[])
{
    if(argc<2)
    {
        printf("Enter a valid Filename after ./a.out");// aftyer a.out should be passed
        return 0;
    }
    char name[256];
    int line = 0;
    FILE *fp = fopen(argv[1],"r");//opening the file using cmnd line argument 
    int openP = 0, closeP = 0;
int openB = 0, closeB = 0;
int openC = 0, closeC = 0;

    while (fgets(name,sizeof(name),fp)) //from the file pointer ends when file is at EOF
    {
        line++;
        if (name[0] == '#') 
        {
        name[strcspn(name, "\n")] = '\0';  // remove newline character
       printf("| \033[1;45m%-15s\033[0m | %-15s |\n", "PRE PROCESSOR", name); //if the line strts with #print as preprocessor
        continue; //skipping the entire line of code 
        }
        char temp[100];
        char ch;
        int j = 0;

        for (int i=0;name[i]!='\0';i++)
        {
            if (name[i] == '"')
{
    i++;
    while (name[i] != '"' && name[i] != '\0')
        i++;

    if (name[i] == '\0')
{
    printf("| UNCLOSED STRING | \" | LINE: %d |\n", line);
    j = 0;
    memset(temp, 0, sizeof(temp));
    break;
}
    continue;
}

// Check unclosed single quote '
if (name[i] == '\'')
{
    i++;
    while (name[i] != '\'' && name[i] != '\0')
        i++;

    if (name[i] == '\0')
    {
        printf("| UNCLOSED CHAR   | ' | LINE: %d |\n", line);
j = 0;
memset(temp, 0, sizeof(temp));
break;
    }
    continue;
}
        ch=name[i]; 
        if (ch == '(') openP++;
else if (ch == ')') closeP++;
else if (ch == '{') openB++;
else if (ch == '}') closeB++;
else if (ch == '[') openC++;
else if (ch == ']') closeC++;
       if ((ch>='a' && ch<='z') || (ch >='A' && ch<='Z') ||(ch >='0'&& ch <='9') || ch=='_' || ch=='#')
            {
                temp[j++] = ch;//until jsut checcking if the charecter s are falls under which segement like brackets and " from now tokeninzing them byn storing them into a array
            }
            else
            {
                if(j!=0)
{
    temp[j]='\0';
    int k = 0;
    while(temp[k]==' '||temp[k]=='\t') 
    {
    k++;
    }
    if (strlen(temp + k) > 0)
{
    char *tok = temp + k;//base ADDRESS PLUS space this will tokenize things

    if (isalpha(tok[0]) || tok[0] == '_')
    {
        if (keywords(tok)) {}
        else if (checkidentifier(tok)) {}
    }
    else if (isdigit(tok[0]))
    {
        if (number(tok)) {}
    }
    else
    {
        printf("| \033[1;31m%-15s\033[0m | %-15s |\n", "Error", tok);
    }
}
    j=0;
}
                 char doubleoperators[3]={ch,name[i+1],'\0'};
                 char singleoperator[2]={ch,'\0'};
                  if(checkoperator(doubleoperators))
                  {
                    i++;
                  }
                  else if(checkoperator(singleoperator)){}
                  else if(symbol(singleoperator));
                }
            }
            
    }       
  fclose(fp); 
  if (openP != closeP) 
   printf("| \033[1;31mUNCLOSED BRACKET\033[0m | ( | LINE: %d |\n", line);//printing wrroes in red colour 
if (openB != closeB) 
printf("| \033[1;31mUNCLOSED BRACE\033[0m   | { | LINE: %d |\n", line);
if (openC != closeC) 
printf("| \033[1;31mUNCLOSED SQUARE\033[0m  | [ | LINE: %d |\n", line);
}
   

