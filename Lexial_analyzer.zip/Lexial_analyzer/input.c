#include<stdio.h>
int  main()
{
  int _k
  int num=0xh;
}